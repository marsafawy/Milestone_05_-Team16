#include <Wire.h>
#include <I2Cdev.h>
#include <MPU6050_6Axis_MotionApps20.h>
#include <Servo.h>

// ================= MOTOR SETUP =================
#define MOTOR_ENA_PIN   5
#define MOTOR_IN1_PIN   7
#define MOTOR_IN2_PIN   8

int motorPWM = 220;

// ================= SERVO SETUP =================
#define STEERING_SERVO_PIN      10
#define STEERING_MIN_ANGLE      5
#define STEERING_MAX_ANGLE      85
#define STEERING_CENTER_ANGLE   45

Servo steeringServo;

// Change this if steering correction is reversed
const int STEERING_DIRECTION = 1;

// ================= PID SETUP =================
float targetYaw = 0.0;

float Kp = 20;
float Ki = 0.001;
float Kd = 0.2;

float yawError = 0.0;
float lastYawError = 0.0;
float yawIntegral = 0.0;
float yawDerivative = 0.0;

unsigned long lastPIDTime = 0;

const float MAX_PID_OUTPUT = 40.0;
const float MAX_INTEGRAL = 50.0;

// ================= SERIAL DEBUG SETUP =================
const unsigned long SERIAL_PRINT_INTERVAL_MS = 200;
unsigned long lastSerialPrintTime = 0;

// ================= ENCODER SETUP =================
#define ENCODER_A_PIN   2
#define ENCODER_B_PIN   3

volatile long encoderTicks = 0;
volatile byte lastEncoderState = 0;

const float TICKS_PER_REV = 4300.0;
const float WHEEL_DIAMETER_CM = 6.6;
const float WHEEL_CIRCUMFERENCE_CM = PI * WHEEL_DIAMETER_CM;

const int ENCODER_SIGN = -1;

// ================= ROUTE / TRACK SETUP =================
// Geometry (Centimeters)
const float STRAIGHT_H_LENGTH = 300.0;
const float STRAIGHT_V_LENGTH = 200.0;
const float CORNER_RADIUS = 75.0; // Center line radius 
const float CORNER_LENGTH = (PI / 2.0) * CORNER_RADIUS; // ~117.81 cm

// 1 for Counter-Clockwise (Left turns), -1 for Clockwise (Right turns)
const float TURN_DIRECTION = 1.0; 

// Track Checkpoints
const float CP1 = STRAIGHT_H_LENGTH;
const float CP2 = CP1 + CORNER_LENGTH;
const float CP3 = CP2 + STRAIGHT_V_LENGTH;
const float CP4 = CP3 + CORNER_LENGTH;
const float CP5 = CP4 + STRAIGHT_H_LENGTH;
const float CP6 = CP5 + CORNER_LENGTH;
const float CP7 = CP6 + STRAIGHT_V_LENGTH;
const float CP8 = CP7 + CORNER_LENGTH;

bool robotStopped = false;
float baseYaw = 0.0;

enum RouteState {
  ROUTE_NONE,
  ROUTE_STRAIGHT_1,
  ROUTE_TURN_1,
  ROUTE_STRAIGHT_2,
  ROUTE_TURN_2,
  ROUTE_STRAIGHT_3,
  ROUTE_TURN_3,
  ROUTE_STRAIGHT_4,
  ROUTE_TURN_4,
  ROUTE_STOPPED
};

RouteState routeState = ROUTE_NONE;

// ================= MPU SETUP =================
MPU6050 mpu(0x68);
uint8_t fifoBuffer[64];
Quaternion q;
VectorFloat gravity;
float ypr[3];
bool dmpReady = false;
float yaw = 0;
float pitch = 0;
float roll = 0;

// ================= MOTOR FUNCTIONS =================
void motorForward(int pwm) {
  pwm = constrain(pwm, 0, 255);
  digitalWrite(MOTOR_IN1_PIN, HIGH);
  digitalWrite(MOTOR_IN2_PIN, LOW);
  analogWrite(MOTOR_ENA_PIN, pwm);
}

void motorStop() {
  analogWrite(MOTOR_ENA_PIN, 0);
  digitalWrite(MOTOR_IN1_PIN, LOW);
  digitalWrite(MOTOR_IN2_PIN, LOW);
}

// ================= ENCODER ISR =================
void updateEncoder() {
  byte A = digitalRead(ENCODER_A_PIN);
  byte B = digitalRead(ENCODER_B_PIN);

  byte currentState = (A << 1) | B;
  byte transition = (lastEncoderState << 2) | currentState;

  if (transition == 0b1101 || transition == 0b0100 || transition == 0b0010 || transition == 0b1011) { encoderTicks++; }
  if (transition == 0b1110 || transition == 0b0111 || transition == 0b0001 || transition == 0b1000) { encoderTicks--; }

  lastEncoderState = currentState;
}

// ================= DISTANCE FUNCTIONS =================
float readDistance() {
  long ticksCopy;
  noInterrupts();
  ticksCopy = encoderTicks;
  interrupts();

  long signedTicks = ENCODER_SIGN * ticksCopy;
  return (signedTicks / TICKS_PER_REV) * WHEEL_CIRCUMFERENCE_CM;
}

void resetDistance() {
  noInterrupts();
  encoderTicks = 0;
  interrupts();
}

// ================= SERVO FUNCTIONS =================
void Set_Steering(int angle) {
  angle = constrain(angle, STEERING_MIN_ANGLE, STEERING_MAX_ANGLE);
  steeringServo.write(angle);
}

void Center_Steering() {
  Set_Steering(STEERING_CENTER_ANGLE);
}

// ================= YAW FUNCTIONS =================
bool Update_Yaw() {
  if (!dmpReady) return false;
  if (mpu.dmpGetCurrentFIFOPacket(fifoBuffer)) {
    mpu.dmpGetQuaternion(&q, fifoBuffer);
    mpu.dmpGetGravity(&gravity, &q);
    mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);
    yaw = ypr[0] * 180.0 / PI;
    return true;
  }
  return false;
}

float Get_Yaw() { return yaw; }

float Angle_Error(float target, float current) {
  float error = target - current;
  while (error > 180.0) error -= 360.0;
  while (error < -180.0) error += 360.0;
  return error;
}

void Reset_Target_Yaw_To_Current() {
  int validReadings = 0;
  unsigned long startTime = millis();
  while (validReadings < 5 && millis() - startTime < 1000) {
    if (Update_Yaw()) validReadings++;
    delay(20);
  }
  targetYaw = Get_Yaw();
  lastYawError = 0.0;
  lastPIDTime = millis();
  Serial.print(F("New target yaw: "));
  Serial.println(targetYaw, 2);
}

// ================= ROUTE FUNCTIONS =================
void Change_Route_State(RouteState newState) {
  if (routeState == newState) return;
  routeState = newState;

  Serial.print(F("Phase: "));
  switch (routeState) {
    case ROUTE_STRAIGHT_1: Serial.println(F("Straight 1 (Bottom)")); break;
    case ROUTE_TURN_1:     Serial.println(F("Turn 1")); break;
    case ROUTE_STRAIGHT_2: Serial.println(F("Straight 2 (Right)")); break;
    case ROUTE_TURN_2:     Serial.println(F("Turn 2")); break;
    case ROUTE_STRAIGHT_3: Serial.println(F("Straight 3 (Top)")); break;
    case ROUTE_TURN_3:     Serial.println(F("Turn 3")); break;
    case ROUTE_STRAIGHT_4: Serial.println(F("Straight 4 (Left)")); break;
    case ROUTE_TURN_4:     Serial.println(F("Turn 4")); break;
    case ROUTE_STOPPED:    
      Serial.println(F("Lap Complete. Stopping.")); 
      motorStop();
      Center_Steering();
      robotStopped = true;
      break;
    default: break;
  }
}

void Update_Route() {
  float distanceCm = readDistance();

  if (distanceCm >= CP8) {
    Change_Route_State(ROUTE_STOPPED);
    return;
  }

  RouteState nextState;
  float nextTargetYaw = baseYaw;

  if (distanceCm < CP1) {
    nextState = ROUTE_STRAIGHT_1;
    nextTargetYaw = baseYaw;
  } 
  else if (distanceCm < CP2) {
    nextState = ROUTE_TURN_1;
    float progress = (distanceCm - CP1) / CORNER_LENGTH;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * progress * 90.0);
  } 
  else if (distanceCm < CP3) {
    nextState = ROUTE_STRAIGHT_2;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * 90.0);
  } 
  else if (distanceCm < CP4) {
    nextState = ROUTE_TURN_2;
    float progress = (distanceCm - CP3) / CORNER_LENGTH;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * 90.0) + (TURN_DIRECTION * progress * 90.0);
  } 
  else if (distanceCm < CP5) {
    nextState = ROUTE_STRAIGHT_3;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * 180.0);
  } 
  else if (distanceCm < CP6) {
    nextState = ROUTE_TURN_3;
    float progress = (distanceCm - CP5) / CORNER_LENGTH;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * 180.0) + (TURN_DIRECTION * progress * 90.0);
  } 
  else if (distanceCm < CP7) {
    nextState = ROUTE_STRAIGHT_4;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * 270.0);
  } 
  else if (distanceCm < CP8) {
    nextState = ROUTE_TURN_4;
    float progress = (distanceCm - CP7) / CORNER_LENGTH;
    nextTargetYaw = baseYaw + (TURN_DIRECTION * 270.0) + (TURN_DIRECTION * progress * 90.0);
  }

  if (routeState != nextState) {
    Change_Route_State(nextState);
  }
  
  // Update global yaw continuously without resetting PID integral
  targetYaw = nextTargetYaw;
}

// ================= PID YAW CONTROL =================
void Maintain_Yaw() {
  if (!Update_Yaw()) return;

  float currentYaw = Get_Yaw();
  unsigned long now = millis();
  float dt = (now - lastPIDTime) / 1000.0;

  if (dt <= 0.0) return;
  lastPIDTime = now;

  yawError = Angle_Error(targetYaw, currentYaw);

  yawIntegral += yawError * dt;
  yawIntegral = constrain(yawIntegral, -MAX_INTEGRAL, MAX_INTEGRAL);

  yawDerivative = (yawError - lastYawError) / dt;
  lastYawError = yawError;

  float pidOutput = (Kp * yawError) + (Ki * yawIntegral) + (Kd * yawDerivative);
  pidOutput = constrain(pidOutput, -MAX_PID_OUTPUT, MAX_PID_OUTPUT);

  int servoAngle = round(STEERING_CENTER_ANGLE + (STEERING_DIRECTION * pidOutput));
  servoAngle = constrain(servoAngle, STEERING_MIN_ANGLE, STEERING_MAX_ANGLE);

  Set_Steering(servoAngle);

  if (now - lastSerialPrintTime >= SERIAL_PRINT_INTERVAL_MS) {
    lastSerialPrintTime = now;
    Serial.print(F("Yaw: "));
    Serial.print(currentYaw, 2);
    Serial.print(F(" | Target: "));
    Serial.print(targetYaw, 2);
    Serial.print(F(" | Err: "));
    Serial.print(yawError, 2);
    Serial.print(F(" | Dist(cm): "));
    Serial.print(readDistance(), 1);
    Serial.print(F(" | PWM: "));
    Serial.println(motorPWM);
  }
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(MOTOR_ENA_PIN, OUTPUT);
  pinMode(MOTOR_IN1_PIN, OUTPUT);
  pinMode(MOTOR_IN2_PIN, OUTPUT);
  motorStop();

  pinMode(ENCODER_A_PIN, INPUT_PULLUP);
  pinMode(ENCODER_B_PIN, INPUT_PULLUP);
  lastEncoderState = (digitalRead(ENCODER_A_PIN) << 1) | digitalRead(ENCODER_B_PIN);
  attachInterrupt(digitalPinToInterrupt(ENCODER_A_PIN), updateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_B_PIN), updateEncoder, CHANGE);
  resetDistance();

  steeringServo.attach(STEERING_SERVO_PIN);
  Center_Steering();

  Wire.begin();
  Wire.setClock(100000);
  mpu.initialize();
  
  if (!mpu.testConnection()) {
    Serial.println(F("MPU FAILED"));
    while (1);
  }

  uint8_t devStatus = mpu.dmpInitialize();
  mpu.setXGyroOffset(220);
  mpu.setYGyroOffset(76);
  mpu.setZGyroOffset(-85);
  mpu.setZAccelOffset(1788);

  if (devStatus == 0) {
    delay(500);
    mpu.CalibrateAccel(6);
    mpu.CalibrateGyro(6);
    mpu.setDMPEnabled(true);
    dmpReady = true;
  } else {
    Serial.println(F("DMP FAILED"));
    while (1);
  }

  delay(1000);
  Reset_Target_Yaw_To_Current();
  baseYaw = targetYaw;

  Serial.println(F("System ready. Starting lap..."));
  motorForward(motorPWM);
}

// ================= LOOP =================
void loop() {
  Update_Route();

  if (!robotStopped) {
    Maintain_Yaw();
  }

  delay(50);
}