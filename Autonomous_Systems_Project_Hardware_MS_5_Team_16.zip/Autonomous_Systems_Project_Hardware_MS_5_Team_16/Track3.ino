#include <Arduino.h>
#include <Wire.h>
#include <I2Cdev.h>
#include <MPU6050_6Axis_MotionApps20.h>
#include <Servo.h>


// =====================================================
// MOTOR SETUP
// =====================================================
#define MOTOR_ENA_PIN   5
#define MOTOR_IN1_PIN   7
#define MOTOR_IN2_PIN   8

const int BASE_MOTOR_PWM = 220;
const int MIN_MOTOR_PWM = 30;
const int MAX_MOTOR_PWM = 255;

int motorPWM = BASE_MOTOR_PWM;

// =====================================================
// SERVO SETUP
// =====================================================
#define STEERING_SERVO_PIN      10
#define STEERING_MIN_ANGLE      15
#define STEERING_MAX_ANGLE      75
#define STEERING_CENTER_ANGLE   45

Servo steeringServo;

// Change to -1 if steering correction is reversed.
const int STEERING_DIRECTION = 1;

// =====================================================
// ENCODER SETUP
// =====================================================
#define ENCODER_A_PIN   2
#define ENCODER_B_PIN   3

volatile long encoderTicks = 0;
volatile byte lastEncoderState = 0;

const float TICKS_PER_REV = 4300.0;
const float WHEEL_DIAMETER_CM = 6.6;
const float WHEEL_CIRCUMFERENCE_CM = PI * WHEEL_DIAMETER_CM;

// If forward motion gives negative distance, keep this = -1.
// If forward motion gives positive distance, change it to 1.
const int ENCODER_SIGN = -1;

// =====================================================
// MPU SETUP
// =====================================================
MPU6050 mpu(0x68);

uint8_t fifoBuffer[64];

Quaternion q;
VectorFloat gravity;
float ypr[3];

bool dmpReady = false;

float yaw = 0.0;
float pitch = 0.0;
float roll = 0.0;

// =====================================================
// YAW PID SETUP
// =====================================================
float targetYaw = 0.0;
float baseYaw = 0.0;

float yawKp = 10.0;                                                                                             //************************************
float yawKi = 0.00;
float yawKd = 0.8;

float yawError = 0.0;
float lastYawError = 0.0;
float yawIntegral = 0.0;
float yawDerivative = 0.0;

unsigned long lastYawPIDTime = 0;

const float MAX_YAW_PID_OUTPUT = 30.0;
const float MAX_YAW_INTEGRAL = 50.0;

// =====================================================
// SPEED CONTROL SETUP
// =====================================================
float targetSpeedCmS = 0.0;
float measuredSpeedCmS = 0.0;

float speedKp = 1.2;                                                                                   //************************************
float speedKi = 0.30;
float speedKd = 0.00;

float speedError = 0.0;
float lastSpeedError = 0.0;
float speedIntegral = 0.0;
float speedDerivative = 0.0;

const float MAX_SPEED_INTEGRAL = 80.0;

// =====================================================
// ODOMETRY SETUP
// =====================================================
float xCm = 0.0;
float yCm = 0.0;

float vxCmS = 0.0;
float vyCmS = 0.0;

// If calculated Y movement is reversed, change this to -1.
const int ODOMETRY_Y_DIRECTION = 1;

unsigned long lastMotionUpdateTime = 0;
float lastMotionDistanceCm = 0.0;

// =====================================================
// POINT NAVIGATION SETUP
// =====================================================
const float NAV_CRUISE_SPEED_CM_S = 15.0;                                                     //************************************
const float NAV_SLOW_SPEED_CM_S = 15.0;
const float NAV_SLOWDOWN_RADIUS_CM = 50.0;

float navigationTargetXcm = 0.0;
float navigationTargetYcm = 0.0;
float navigationDistanceToTargetCm = 0.0;
float navigationDesiredThetaDeg = 0.0;

bool robotStopped = false;

// =====================================================
// WAYPOINT ARRAY SETUP
// =====================================================
// All points are in centimeters.
//
// Example:
// x = 3 m       -> 300 cm
// y = 0.1875 m  -> 18.75 cm

struct Point2D {
  float xCm;
  float yCm;
};

// Edit this array to change the path.
Point2D targetPoints[] = {
  // Rear axle starts at the red cross
  {0.0, 0.0},

  // Top straight
  {32.0, 0.0},
  {82.0, 0.0},
  {132.0, 0.0},
  {182.0, 0.0},
  {232.0, 0.0},
  {272.0, 0.0},

  // Top-right curvature
  {285.3, 2.0},
  {298.7, 1.6},
  {311.9, -1.0},
  {324.4, -6.0},
  {335.9, -13.0},
  {346.0, -21.9},
  {354.3, -32.4},
  {360.7, -44.2},
  {365.0, -57.0},

  // Right straight
  {365.0, -82.0},
  {365.0, -132.0},
  {365.0, -182.0},
  {365.0, -232.0},
  {365.0, -257.0},

  // Bottom-right curvature
  {367.0, -270.3},
  {366.6, -283.7},
  {364.0, -296.9},
  {359.0, -309.4},
  {352.0, -320.9},
  {343.1, -331.0},
  {332.6, -339.3},
  {320.8, -345.7},
  {308.0, -350.0},

  // Bottom straight
  {258.0, -350.0},
  {208.0, -350.0},
  {158.0, -350.0},
  {108.0, -350.0},
  {58.0, -350.0},
  {8.0, -350.0},

  // Bottom-left curvature
  {-5.3, -352.0},
  {-18.7, -351.6},
  {-31.9, -349.0},
  {-44.4, -344.0},
  {-55.9, -337.0},
  {-66.0, -328.1},
  {-74.3, -317.6},
  {-80.7, -305.8},
  {-85.0, -293.0},

  // Left straight
  {-85.0, -268.0},
  {-85.0, -218.0},
  {-85.0, -168.0},
  {-85.0, -118.0},
  {-85.0, -93.0},

  // Top-left curvature
  {-87.0, -79.7},
  {-86.6, -66.3},
  {-84.0, -53.1},
  {-79.0, -40.6},
  {-72.0, -29.1},
  {-63.1, -19.0},
  {-52.6, -10.7},
  {-40.8, -4.3},

  // Final rear axle target
  // At this point, the front axle is approximately back at the red cross.
  {-18.0, 0.0}

};


const int TOTAL_TARGET_POINTS = sizeof(targetPoints) / sizeof(targetPoints[0]);

const float WAYPOINT_TOLERANCE_CM = 8.0;

int currentPointIndex = 1;

// =====================================================
// SERIAL DEBUG SETUP
// =====================================================
const unsigned long SERIAL_PRINT_INTERVAL_MS = 200;
unsigned long lastSerialPrintTime = 0;

// =====================================================
// FUNCTION PROTOTYPES
// =====================================================
void motorForward(int pwm);
void motorStop();

void updateEncoder();
float readDistance();
void resetDistance();

void Set_Steering(int angle);
void Center_Steering();

bool Update_Yaw();
float Get_Yaw();
float Normalize_Angle(float angle);
float Angle_Error(float target, float current);

void Set_Target_Yaw_ResetPID(float target);
void Set_Target_Yaw_Continuous(float target);
void Reset_Target_Yaw_To_Current();
void Maintain_Yaw();

void Set_Target_Speed_CmS(float speedCmS);
void Initialize_Motion_Estimation();
float Heading_Relative_To_Base();
void Update_Motion_And_Speed_Control();

bool Go_To_Point(float targetXcm, float targetYcm, float toleranceCm);
bool Follow_Point_Array();
void Stop_Robot();

void Print_Debug(float currentYaw, float pidOutput, int servoAngle);
void Wait_For_Start_Command();

// =====================================================
// ================= CITY TRACK SETUP =================
// =====================================================

// Track dimensions in centimeters.
// Based on centerline driving.

const float CITY_STRAIGHT_H_LENGTH = 300.0;   // horizontal straight
const float CITY_STRAIGHT_V_LENGTH = 200.0;   // vertical straight
const float CITY_CORNER_RADIUS     = 75.0;    // centerline radius
const float CITY_CORNER_LENGTH     = (PI / 2.0) * CITY_CORNER_RADIUS;

const float CITY_STRAIGHT_SPEED_CM_S = 30.0;                                                          //************************************                           
const float CITY_TURN_SPEED_CM_S     = 30.0;

// 1  = counter-clockwise / left turns
// -1 = clockwise / right turns
const float CITY_TURN_DIRECTION = 1.0;

// Checkpoints around one full lap
const float CITY_CP1 = CITY_STRAIGHT_H_LENGTH;
const float CITY_CP2 = CITY_CP1 + CITY_CORNER_LENGTH;
const float CITY_CP3 = CITY_CP2 + CITY_STRAIGHT_V_LENGTH;
const float CITY_CP4 = CITY_CP3 + CITY_CORNER_LENGTH;
const float CITY_CP5 = CITY_CP4 + CITY_STRAIGHT_H_LENGTH;
const float CITY_CP6 = CITY_CP5 + CITY_CORNER_LENGTH;
const float CITY_CP7 = CITY_CP6 + CITY_STRAIGHT_V_LENGTH;
const float CITY_CP8 = CITY_CP7 + CITY_CORNER_LENGTH;

enum CityRouteState {
  CITY_NONE,
  CITY_STRAIGHT_1,
  CITY_TURN_1,
  CITY_STRAIGHT_2,
  CITY_TURN_2,
  CITY_STRAIGHT_3,
  CITY_TURN_3,
  CITY_STRAIGHT_4,
  CITY_TURN_4,
  CITY_STOPPED
};

CityRouteState cityRouteState = CITY_NONE;

void Change_City_State(CityRouteState newState) {
  if (cityRouteState == newState) {
    return;
  }

  cityRouteState = newState;

  Serial.print(F("City phase: "));

  switch (cityRouteState) {
case CITY_STRAIGHT_1:
  Serial.println(F("Straight 1"));
  Set_Target_Speed_CmS(CITY_STRAIGHT_SPEED_CM_S);
  break;

case CITY_TURN_1:
  Serial.println(F("Turn 1"));
  Set_Target_Speed_CmS(CITY_TURN_SPEED_CM_S);
  break;

case CITY_STRAIGHT_2:
  Serial.println(F("Straight 2"));
  Set_Target_Speed_CmS(CITY_STRAIGHT_SPEED_CM_S);
  break;

case CITY_TURN_2:
  Serial.println(F("Turn 2"));
  Set_Target_Speed_CmS(CITY_TURN_SPEED_CM_S);
  break;

case CITY_STRAIGHT_3:
  Serial.println(F("Straight 3"));
  Set_Target_Speed_CmS(CITY_STRAIGHT_SPEED_CM_S);
  break;

case CITY_TURN_3:
  Serial.println(F("Turn 3"));
  Set_Target_Speed_CmS(CITY_TURN_SPEED_CM_S);
  break;

case CITY_STRAIGHT_4:
  Serial.println(F("Straight 4"));
  Set_Target_Speed_CmS(CITY_STRAIGHT_SPEED_CM_S);
  break;

case CITY_TURN_4:
  Serial.println(F("Turn 4"));
  Set_Target_Speed_CmS(CITY_TURN_SPEED_CM_S);
  break;

case CITY_STOPPED:
  Serial.println(F("Lap complete. Stopping."));
  Set_Target_Speed_CmS(0.0);
  motorStop();
  Center_Steering();
  robotStopped = true;
  break;

    default:
      break;
  }
}

// ================= CITY TRACK FUNCTION =================
// This function updates targetYaw based on encoder distance.
// Maintain_Yaw() will then control the servo to follow that target.

void Update_City_Track() {
  float distanceCm = readDistance();

  if (distanceCm >= CITY_CP8) {
    Change_City_State(CITY_STOPPED);
    return;
  }

  CityRouteState nextState = CITY_NONE;
  float nextTargetYaw = baseYaw;

  // Bottom / first horizontal straight
  if (distanceCm < CITY_CP1) {
    nextState = CITY_STRAIGHT_1;
    nextTargetYaw = baseYaw;
  }

  // First 90-degree corner
  else if (distanceCm < CITY_CP2) {
    nextState = CITY_TURN_1;

    float progress = (distanceCm - CITY_CP1) / CITY_CORNER_LENGTH;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * progress * 90.0);
  }

  // First vertical straight
  else if (distanceCm < CITY_CP3) {
    nextState = CITY_STRAIGHT_2;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * 90.0);
  }

  // Second 90-degree corner
  else if (distanceCm < CITY_CP4) {
    nextState = CITY_TURN_2;

    float progress = (distanceCm - CITY_CP3) / CITY_CORNER_LENGTH;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * 90.0)
                          + (CITY_TURN_DIRECTION * progress * 90.0);
  }

  // Second horizontal straight
  else if (distanceCm < CITY_CP5) {
    nextState = CITY_STRAIGHT_3;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * 180.0);
  }

  // Third 90-degree corner
  else if (distanceCm < CITY_CP6) {
    nextState = CITY_TURN_3;

    float progress = (distanceCm - CITY_CP5) / CITY_CORNER_LENGTH;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * 180.0)
                          + (CITY_TURN_DIRECTION * progress * 90.0);
  }

  // Second vertical straight
  else if (distanceCm < CITY_CP7) {
    nextState = CITY_STRAIGHT_4;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * 270.0);
  }

  // Fourth 90-degree corner
  else {
    nextState = CITY_TURN_4;

    float progress = (distanceCm - CITY_CP7) / CITY_CORNER_LENGTH;
    nextTargetYaw = baseYaw + (CITY_TURN_DIRECTION * 270.0)
                          + (CITY_TURN_DIRECTION * progress * 90.0);
  }

  Change_City_State(nextState);

  // Important:
  // We update targetYaw continuously here.
  // Do NOT call Set_Target_Yaw() every loop, because that resets the PID integral.
  targetYaw = nextTargetYaw;
}

// =====================================================
// Raspbbery pi start function
// =====================================================

void Wait_For_Start_Command() {
  Serial.println(F("WAITING_FOR_S_COMMAND"));

  Stop_Robot();
  robotStopped = true;

  while (true) {
    Stop_Robot();

    if (Serial.available() > 0) {
      char command = Serial.read();

      if (command == 'S' || command == 's') {
        Serial.println(F("S_RECEIVED_STARTING"));

        // Reset everything exactly at the real start moment
        resetDistance();

        // Because point 0 is the start point / red cross
        currentPointIndex = 1;

        Reset_Target_Yaw_To_Current();
        baseYaw = targetYaw;

        Initialize_Motion_Estimation();

        cityRouteState = CITY_NONE;
        robotStopped = false;

        break;
      }
    }

    delay(20);
  }
}

// =====================================================
// MOTOR FUNCTIONS
// =====================================================
void motorForward(int pwm) {
  pwm = constrain(pwm, 0, 255);

  digitalWrite(MOTOR_IN1_PIN, HIGH);
  digitalWrite(MOTOR_IN2_PIN, LOW);
  analogWrite(MOTOR_ENA_PIN, pwm);
}

void motorStop() {
  analogWrite(MOTOR_ENA_PIN, 0);
  digitalWrite(MOTOR_IN1_PIN, LOW);
  digitalWrite(MOTOR_IN2_PIN, LOW);
}

// =====================================================
// ENCODER ISR
// =====================================================
void updateEncoder() {
  byte A = digitalRead(ENCODER_A_PIN);
  byte B = digitalRead(ENCODER_B_PIN);

  byte currentState = (A << 1) | B;
  byte transition = (lastEncoderState << 2) | currentState;

  if (
    transition == 0b1101 ||
    transition == 0b0100 ||
    transition == 0b0010 ||
    transition == 0b1011
  ) {
    encoderTicks++;
  }

  if (
    transition == 0b1110 ||
    transition == 0b0111 ||
    transition == 0b0001 ||
    transition == 0b1000
  ) {
    encoderTicks--;
  }

  lastEncoderState = currentState;
}

// =====================================================
// DISTANCE FUNCTIONS
// =====================================================
float readDistance() {
  long ticksCopy;

  noInterrupts();
  ticksCopy = encoderTicks;
  interrupts();

  long signedTicks = ENCODER_SIGN * ticksCopy;

  float rotations = signedTicks / TICKS_PER_REV;
  float distanceCm = rotations * WHEEL_CIRCUMFERENCE_CM;

  return distanceCm;
}

void resetDistance() {
  noInterrupts();
  encoderTicks = 0;
  interrupts();
}

// =====================================================
// SERVO FUNCTIONS
// =====================================================
void Set_Steering(int angle) {
  angle = constrain(angle, STEERING_MIN_ANGLE, STEERING_MAX_ANGLE);
  steeringServo.write(angle);
}

void Center_Steering() {
  Set_Steering(STEERING_CENTER_ANGLE);
}

// =====================================================
// ANGLE FUNCTIONS
// =====================================================
float Normalize_Angle(float angle) {
  while (angle > 180.0) {
    angle -= 360.0;
  }

  while (angle < -180.0) {
    angle += 360.0;
  }

  return angle;
}

float Angle_Error(float target, float current) {
  float error = target - current;

  while (error > 180.0) {
    error -= 360.0;
  }

  while (error < -180.0) {
    error += 360.0;
  }

  return error;
}

// =====================================================
// MPU / YAW FUNCTIONS
// =====================================================
bool Update_Yaw() {
  if (!dmpReady) {
    return false;
  }

  if (mpu.dmpGetCurrentFIFOPacket(fifoBuffer)) {
    mpu.dmpGetQuaternion(&q, fifoBuffer);
    mpu.dmpGetGravity(&gravity, &q);
    mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);

    yaw   = ypr[0] * 180.0 / PI;
    pitch = ypr[1] * 180.0 / PI;
    roll  = ypr[2] * 180.0 / PI;

    return true;
  }

  return false;
}

float Get_Yaw() {
  return yaw;
}

void Set_Target_Yaw_ResetPID(float target) {
  targetYaw = Normalize_Angle(target);

  yawIntegral = 0.0;
  lastYawError = Angle_Error(targetYaw, Get_Yaw());
  lastYawPIDTime = millis();
}

// Used when the target yaw changes continuously during point navigation.
// This avoids resetting the yaw PID every loop.
void Set_Target_Yaw_Continuous(float target) {
  targetYaw = Normalize_Angle(target);
}

void Reset_Target_Yaw_To_Current() {
  int validReadings = 0;
  unsigned long startTime = millis();

  while (validReadings < 5 && millis() - startTime < 1000) {
    if (Update_Yaw()) {
      validReadings++;
    }

    delay(20);
  }

  float currentYaw = Get_Yaw();
  Set_Target_Yaw_ResetPID(currentYaw);

  Serial.print(F("New target yaw: "));
  Serial.println(targetYaw, 2);
}

// =====================================================
// YAW PID CONTROL
// =====================================================
void Maintain_Yaw() {
  if (!Update_Yaw()) {
    return;
  }

  float currentYaw = Get_Yaw();

  unsigned long now = millis();
  float dt = (now - lastYawPIDTime) / 1000.0;

  if (dt <= 0.0) {
    return;
  }

  lastYawPIDTime = now;

  yawError = Angle_Error(targetYaw, currentYaw);

  yawIntegral += yawError * dt;
  yawIntegral = constrain(yawIntegral, -MAX_YAW_INTEGRAL, MAX_YAW_INTEGRAL);

  yawDerivative = (yawError - lastYawError) / dt;
  lastYawError = yawError;

  float pidOutput =
    (yawKp * yawError) +
    (yawKi * yawIntegral) +
    (yawKd * yawDerivative);

  pidOutput = constrain(pidOutput, -MAX_YAW_PID_OUTPUT, MAX_YAW_PID_OUTPUT);

  int servoAngle = round(STEERING_CENTER_ANGLE + (STEERING_DIRECTION * pidOutput));
  servoAngle = constrain(servoAngle, STEERING_MIN_ANGLE, STEERING_MAX_ANGLE);

  Set_Steering(servoAngle);

  Print_Debug(currentYaw, pidOutput, servoAngle);
}

// =====================================================
// SPEED / ODOMETRY FUNCTIONS
// =====================================================
void Set_Target_Speed_CmS(float speedCmS) {
  if (speedCmS < 0.0) {
    speedCmS = 0.0;
  }

  targetSpeedCmS = speedCmS;

  speedIntegral = 0.0;
  lastSpeedError = 0.0;
}

void Initialize_Motion_Estimation() {
  xCm = 0.0;
  yCm = 0.0;

  measuredSpeedCmS = 0.0;
  vxCmS = 0.0;
  vyCmS = 0.0;

  speedIntegral = 0.0;
  lastSpeedError = 0.0;

  lastMotionDistanceCm = readDistance();
  lastMotionUpdateTime = millis();
}

float Heading_Relative_To_Base() {
  return Angle_Error(Get_Yaw(), baseYaw);
}

void Update_Motion_And_Speed_Control() {
  unsigned long now = millis();

  if (lastMotionUpdateTime == 0) {
    Initialize_Motion_Estimation();
    return;
  }

  float dt = (now - lastMotionUpdateTime) / 1000.0;

  if (dt <= 0.0) {
    return;
  }

  lastMotionUpdateTime = now;

  // ---------- Measure speed from encoder ----------
  float currentDistanceCm = readDistance();
  float deltaDistanceCm = currentDistanceCm - lastMotionDistanceCm;
  lastMotionDistanceCm = currentDistanceCm;

  float rawSpeedCmS = deltaDistanceCm / dt;

  // Simple low-pass filter to reduce speed noise.
  measuredSpeedCmS = (0.7 * measuredSpeedCmS) + (0.3 * rawSpeedCmS);

  // ---------- Calculate heading relative to base ----------
  float thetaDeg = Heading_Relative_To_Base();
  float thetaRad = thetaDeg * PI / 180.0;

  // ---------- Calculate velocity components ----------
  vxCmS = measuredSpeedCmS * cos(thetaRad);
  vyCmS = ODOMETRY_Y_DIRECTION * measuredSpeedCmS * sin(thetaRad);

  // ---------- Update estimated position ----------
  xCm = xCm + (vxCmS * dt);
  yCm = yCm + (vyCmS * dt);

  // ---------- True stop protection ----------
  if (targetSpeedCmS <= 0.1) {
    motorPWM = 0;
    speedIntegral = 0.0;
    lastSpeedError = 0.0;
    motorStop();
    return;
  }

  // ---------- Speed PID control ----------
  speedError = targetSpeedCmS - measuredSpeedCmS;

  speedIntegral += speedError * dt;
  speedIntegral = constrain(speedIntegral, -MAX_SPEED_INTEGRAL, MAX_SPEED_INTEGRAL);

  speedDerivative = (speedError - lastSpeedError) / dt;
  lastSpeedError = speedError;

  float speedPIDOutput =
    (speedKp * speedError) +
    (speedKi * speedIntegral) +
    (speedKd * speedDerivative);

  motorPWM = BASE_MOTOR_PWM + round(speedPIDOutput);
  motorPWM = constrain(motorPWM, MIN_MOTOR_PWM, MAX_MOTOR_PWM);

  motorForward(motorPWM);
}

// =====================================================
// POINT NAVIGATION
// =====================================================
// This function only checks and guides the robot toward one point.
// It does not stop the robot permanently.
// Final stopping is handled by Follow_Point_Array().
bool Go_To_Point(float targetXcm, float targetYcm, float toleranceCm) {
  navigationTargetXcm = targetXcm;
  navigationTargetYcm = targetYcm;

  float dx = targetXcm - xCm;
  float dy = targetYcm - yCm;

  float distanceToTargetCm = sqrt((dx * dx) + (dy * dy));
  navigationDistanceToTargetCm = distanceToTargetCm;

  if (distanceToTargetCm <= toleranceCm) {
    return true;
  }

  // Desired heading relative to the original X-axis.
  float desiredThetaRad = atan2(dy, dx);
  float desiredThetaDeg = desiredThetaRad * 180.0 / PI;

  navigationDesiredThetaDeg = desiredThetaDeg;

  // Convert local map heading to real MPU yaw target.
  float desiredYaw = baseYaw + desiredThetaDeg;

  Set_Target_Yaw_Continuous(desiredYaw);

  // Slow down near the current target point.
  float selectedSpeedCmS = NAV_CRUISE_SPEED_CM_S;

  if (distanceToTargetCm < NAV_SLOWDOWN_RADIUS_CM) {
    selectedSpeedCmS = NAV_SLOW_SPEED_CM_S;
  }

  // Avoid resetting the speed PID every loop.
  if (fabs(targetSpeedCmS - selectedSpeedCmS) > 0.5) {
    Set_Target_Speed_CmS(selectedSpeedCmS);
  }

  return false;
}

// =====================================================
// WAYPOINT ARRAY FOLLOWING
// =====================================================
bool Follow_Point_Array() {
  if (currentPointIndex >= TOTAL_TARGET_POINTS) {
    Stop_Robot();
    return true;
  }

  Point2D currentTarget = targetPoints[currentPointIndex];

  bool reachedCurrentPoint = Go_To_Point(
    currentTarget.xCm,
    currentTarget.yCm,
    WAYPOINT_TOLERANCE_CM
  );

  if (reachedCurrentPoint) {
    Serial.print(F("Reached point "));
    Serial.print(currentPointIndex + 1);
    Serial.print(F(" / "));
    Serial.println(TOTAL_TARGET_POINTS);

    currentPointIndex++;

    if (currentPointIndex >= TOTAL_TARGET_POINTS) {
      Stop_Robot();
      Serial.println(F("Final point reached. Robot stopped."));
      return true;
    }

    Point2D nextTarget = targetPoints[currentPointIndex];

    Serial.print(F("Going to next point "));
    Serial.print(currentPointIndex + 1);
    Serial.print(F(" | X = "));
    Serial.print(nextTarget.xCm, 2);
    Serial.print(F(" cm, Y = "));
    Serial.print(nextTarget.yCm, 2);
    Serial.println(F(" cm"));

    // Immediately update yaw and speed toward the next point.
    Go_To_Point(
      nextTarget.xCm,
      nextTarget.yCm,
      WAYPOINT_TOLERANCE_CM
    );
  }

  return false;
}

void Stop_Robot() {
  Set_Target_Speed_CmS(0.0);
  motorStop();
  Center_Steering();
}

// =====================================================
// SERIAL DEBUG FUNCTION
// =====================================================
void Print_Debug(float currentYaw, float pidOutput, int servoAngle) {
  // Keep same function arguments so the rest of the code does not need changes
  (void)pidOutput;
  (void)servoAngle;

  unsigned long now = millis();

  if (now - lastSerialPrintTime < SERIAL_PRINT_INTERVAL_MS) {
    return;
  }

  lastSerialPrintTime = now;

  Serial.print(F("Yaw: "));
  Serial.print(currentYaw, 2);

  Serial.print(F(" | X(cm): "));
  Serial.print(xCm, 2);

  Serial.print(F(" | Y(cm): "));
  Serial.print(yCm, 2);

  Serial.print(F(" | Vx(cm/s): "));
  Serial.print(vxCmS, 2);

  Serial.print(F(" | Vy(cm/s): "));
  Serial.print(vyCmS, 2);

  Serial.print(F(" | TotalDistance(cm): "));
  Serial.print(readDistance(), 2);

  Serial.print(F(" | Speed(cm/s): "));
  Serial.print(measuredSpeedCmS, 2);

  Serial.print(F(" | PWM: "));
  Serial.println(motorPWM);
}

// =====================================================
// SETUP
// =====================================================
void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println(F("Starting city-track control system..."));

  // ---------- Motor ----------
  pinMode(MOTOR_ENA_PIN, OUTPUT);
  pinMode(MOTOR_IN1_PIN, OUTPUT);
  pinMode(MOTOR_IN2_PIN, OUTPUT);

  motorStop();
  Serial.println(F("Motor ready and stopped."));

  // ---------- Encoder ----------
  pinMode(ENCODER_A_PIN, INPUT_PULLUP);
  pinMode(ENCODER_B_PIN, INPUT_PULLUP);

  lastEncoderState = (digitalRead(ENCODER_A_PIN) << 1) | digitalRead(ENCODER_B_PIN);

  attachInterrupt(digitalPinToInterrupt(ENCODER_A_PIN), updateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_B_PIN), updateEncoder, CHANGE);

  resetDistance();
  Serial.println(F("Encoder ready."));

  // ---------- Servo ----------
  steeringServo.attach(STEERING_SERVO_PIN);
  Center_Steering();
  Serial.println(F("Servo centered."));

  // ---------- MPU ----------
  Wire.begin();
  Wire.setClock(100000);

  Serial.println(F("Initializing MPU6050..."));
  mpu.initialize();

  Serial.println(F("Testing MPU connection..."));

  if (mpu.testConnection()) {
    Serial.println(F("MPU6050 connection OK."));
  } else {
    Serial.println(F("MPU6050 connection FAILED."));
    motorStop();

    while (1);
  }

  Serial.println(F("Initializing DMP..."));

  uint8_t devStatus = mpu.dmpInitialize();

  // These offsets may need tuning for your actual MPU.
  mpu.setXGyroOffset(220);
  mpu.setYGyroOffset(76);
  mpu.setZGyroOffset(-85);
  mpu.setZAccelOffset(1788);

  if (devStatus == 0) {
    Serial.println(F("DMP initialized successfully."));
    Serial.println(F("Keep the MPU flat and still. Calibrating..."));

    delay(500);

    mpu.CalibrateAccel(6);
    mpu.CalibrateGyro(6);

    mpu.setDMPEnabled(true);
    dmpReady = true;

    Serial.println(F("DMP ready."));
  } else {
    Serial.print(F("DMP initialization FAILED. Code: "));
    Serial.println(devStatus);
    motorStop();

    while (1);
  }

  delay(1000);

  // Take the starting direction as the X-axis direction.
  Reset_Target_Yaw_To_Current();
  baseYaw = targetYaw;

  Serial.print(F("Base yaw locked: "));
  Serial.println(baseYaw, 2);

  Initialize_Motion_Estimation();

  Serial.println(F("Loaded target points:"));

  for (int i = 0; i < TOTAL_TARGET_POINTS; i++) {
    Serial.print(F("Point "));
    Serial.print(i + 1);
    Serial.print(F(" | X = "));
    Serial.print(targetPoints[i].xCm, 2);
    Serial.print(F(" cm, Y = "));
    Serial.print(targetPoints[i].yCm, 2);
    Serial.println(F(" cm"));
  }

  Serial.print(F("Waypoint tolerance(cm): "));
  Serial.println(WAYPOINT_TOLERANCE_CM, 2);

  Serial.println(F("Send S from Raspberry Pi to start."));
  Wait_For_Start_Command();

  Serial.println(F("Start command received. Running selected loop function."));
}

// =====================================================
// LOOP
// =====================================================

void cityTrack_Distance()
{
  Update_City_Track();

  if (!robotStopped) {
    Maintain_Yaw();
    Update_Motion_And_Speed_Control();
  }

  delay(50);
}

void cityTrack_points_follow()
{
  if (!robotStopped) {
    bool finishedAllPoints = Follow_Point_Array();

    if (finishedAllPoints) {
      robotStopped = true;
      Stop_Robot();
    } else {
      Maintain_Yaw();
      Update_Motion_And_Speed_Control();
    }
  }

  delay(50);
}

void loop() {
  //cityTrack_points_follow();
  cityTrack_Distance();
}

