#include <Wire.h>
#include <I2Cdev.h>
#include <MPU6050_6Axis_MotionApps20.h>
#include <Servo.h>

// ================= MOTOR SETUP =================
#define MOTOR_ENA_PIN   5
#define MOTOR_IN1_PIN   7
#define MOTOR_IN2_PIN   8

int motorPWM = 220;

// ================= SERVO SETUP =================
#define STEERING_SERVO_PIN      10
#define STEERING_MIN_ANGLE      5
#define STEERING_MAX_ANGLE      85
#define STEERING_CENTER_ANGLE   45

Servo steeringServo;

// Change this if steering correction is reversed
const int STEERING_DIRECTION = 1;

// ================= PID SETUP =================
float targetYaw = 0.0;

float Kp = 20;
float Ki = 0.001;
float Kd = 0.2;

float yawError = 0.0;
float lastYawError = 0.0;
float yawIntegral = 0.0;
float yawDerivative = 0.0;

unsigned long lastPIDTime = 0;

const float MAX_PID_OUTPUT = 40.0;
const float MAX_INTEGRAL = 50.0;

// ================= SERIAL DEBUG SETUP =================
const unsigned long SERIAL_PRINT_INTERVAL_MS = 200;
unsigned long lastSerialPrintTime = 0;

// ================= ENCODER SETUP =================
#define ENCODER_A_PIN   2
#define ENCODER_B_PIN   3

volatile long encoderTicks = 0;
volatile byte lastEncoderState = 0;

const float TICKS_PER_REV = 4300.0;
const float WHEEL_DIAMETER_CM = 6.6;
const float WHEEL_CIRCUMFERENCE_CM = PI * WHEEL_DIAMETER_CM;

const int ENCODER_SIGN = -1;

// ================= STRAIGHT OBSTACLE TRACK SETUP =================
//
// Track length = 10 m = 1000 cm
//
// Route:
// Start from middle
// Move to Lane 1
// Before obstacle 1, switch to Lane 2
// Before obstacle 2, switch back to Lane 1
// Stop at 10 m
//

const float TRACK_TOTAL_LENGTH = 1100.0;

// Direction of lane movement.
// It is inverted because your rotation direction was reversed.
// If the robot starts moving to the wrong side again, change this to 1.0.
const float LANE_SIDE_SIGN = -1.0;

// Initial shift from middle to Lane 1
const float INITIAL_LANE_CHANGE_START = 0.0;
const float INITIAL_LANE_CHANGE_MID   = 60.0;
const float INITIAL_LANE_CHANGE_END   = 130.0;
const float INITIAL_LANE_YAW_ANGLE    = 25.0;

// Full lane-change angle
const float FULL_LANE_YAW_ANGLE = 30.0;

// Lane 1 to Lane 2 before obstacle 1
// Obstacle 1 is around 400 cm.
// Starts later than before, but stays turning longer.
const float LC1_START    = 300.0;
const float LC1_RAMP_END = 370.0;
const float LC1_HOLD_END = 440.0;
const float LC1_END      = 540.0;

// Lane 2 to Lane 1 before obstacle 2
// Obstacle 2 is around 800 cm.
const float LC2_START    = 700.0;
const float LC2_RAMP_END = 770.0;
const float LC2_HOLD_END = 840.0;
const float LC2_END      = 940.0;

bool robotStopped = false;
float baseYaw = 0.0;

enum RouteState {
  ROUTE_NONE,
  ROUTE_INITIAL_TO_LANE1,
  ROUTE_LANE1_STRAIGHT,
  ROUTE_LANE1_TO_LANE2,
  ROUTE_LANE2_STRAIGHT,
  ROUTE_LANE2_TO_LANE1,
  ROUTE_FINAL_STRAIGHT,
  ROUTE_STOPPED
};

RouteState routeState = ROUTE_NONE;

// ================= MPU SETUP =================
MPU6050 mpu(0x68);
uint8_t fifoBuffer[64];
Quaternion q;
VectorFloat gravity;
float ypr[3];

bool dmpReady = false;

float yaw = 0;
float pitch = 0;
float roll = 0;

// ================= MOTOR FUNCTIONS =================
void motorForward(int pwm) {
  pwm = constrain(pwm, 0, 255);

  digitalWrite(MOTOR_IN1_PIN, HIGH);
  digitalWrite(MOTOR_IN2_PIN, LOW);
  analogWrite(MOTOR_ENA_PIN, pwm);
}

void motorStop() {
  analogWrite(MOTOR_ENA_PIN, 0);

  digitalWrite(MOTOR_IN1_PIN, LOW);
  digitalWrite(MOTOR_IN2_PIN, LOW);
}

// ================= ENCODER ISR =================
void updateEncoder() {
  byte A = digitalRead(ENCODER_A_PIN);
  byte B = digitalRead(ENCODER_B_PIN);

  byte currentState = (A << 1) | B;
  byte transition = (lastEncoderState << 2) | currentState;

  if (transition == 0b1101 ||
      transition == 0b0100 ||
      transition == 0b0010 ||
      transition == 0b1011) {
    encoderTicks++;
  }

  if (transition == 0b1110 ||
      transition == 0b0111 ||
      transition == 0b0001 ||
      transition == 0b1000) {
    encoderTicks--;
  }

  lastEncoderState = currentState;
}

// ================= DISTANCE FUNCTIONS =================
float readDistance() {
  long ticksCopy;

  noInterrupts();
  ticksCopy = encoderTicks;
  interrupts();

  long signedTicks = ENCODER_SIGN * ticksCopy;

  return (signedTicks / TICKS_PER_REV) * WHEEL_CIRCUMFERENCE_CM;
}

void resetDistance() {
  noInterrupts();
  encoderTicks = 0;
  interrupts();
}

// ================= SERVO FUNCTIONS =================
void Set_Steering(int angle) {
  angle = constrain(angle, STEERING_MIN_ANGLE, STEERING_MAX_ANGLE);
  steeringServo.write(angle);
}

void Center_Steering() {
  Set_Steering(STEERING_CENTER_ANGLE);
}

// ================= YAW FUNCTIONS =================
bool Update_Yaw() {
  if (!dmpReady) return false;

  if (mpu.dmpGetCurrentFIFOPacket(fifoBuffer)) {
    mpu.dmpGetQuaternion(&q, fifoBuffer);
    mpu.dmpGetGravity(&gravity, &q);
    mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);

    yaw = ypr[0] * 180.0 / PI;
    pitch = ypr[1] * 180.0 / PI;
    roll = ypr[2] * 180.0 / PI;

    return true;
  }

  return false;
}

float Get_Yaw() {
  return yaw;
}

float Angle_Error(float target, float current) {
  float error = target - current;

  while (error > 180.0) error -= 360.0;
  while (error < -180.0) error += 360.0;

  return error;
}

void Reset_Target_Yaw_To_Current() {
  int validReadings = 0;
  unsigned long startTime = millis();

  while (validReadings < 5 && millis() - startTime < 1000) {
    if (Update_Yaw()) {
      validReadings++;
    }

    delay(20);
  }

  targetYaw = Get_Yaw();

  lastYawError = 0.0;
  yawIntegral = 0.0;
  yawDerivative = 0.0;
  lastPIDTime = millis();

  Serial.print(F("New target yaw: "));
  Serial.println(targetYaw, 2);
}

// ================= ROUTE FUNCTIONS =================
float getProgress(float distanceCm, float startCm, float endCm) {
  float progress = (distanceCm - startCm) / (endCm - startCm);
  return constrain(progress, 0.0, 1.0);
}

float laneChangeYawProfile(float distanceCm,
                           float startCm,
                           float rampEndCm,
                           float holdEndCm,
                           float endCm,
                           float yawAngle) {
  if (distanceCm < rampEndCm) {
    float progress = getProgress(distanceCm, startCm, rampEndCm);
    return yawAngle * progress;
  }
  else if (distanceCm < holdEndCm) {
    return yawAngle;
  }
  else {
    float progress = getProgress(distanceCm, holdEndCm, endCm);
    return yawAngle * (1.0 - progress);
  }
}

void Change_Route_State(RouteState newState) {
  if (routeState == newState) return;

  routeState = newState;

  Serial.print(F("Phase: "));

  switch (routeState) {
    case ROUTE_INITIAL_TO_LANE1:
      Serial.println(F("Initial shift: Middle -> Lane 1"));
      break;

    case ROUTE_LANE1_STRAIGHT:
      Serial.println(F("Straight in Lane 1"));
      break;

    case ROUTE_LANE1_TO_LANE2:
      Serial.println(F("Lane change: Lane 1 -> Lane 2 before obstacle 1"));
      break;

    case ROUTE_LANE2_STRAIGHT:
      Serial.println(F("Straight in Lane 2"));
      break;

    case ROUTE_LANE2_TO_LANE1:
      Serial.println(F("Lane change: Lane 2 -> Lane 1 before obstacle 2"));
      break;

    case ROUTE_FINAL_STRAIGHT:
      Serial.println(F("Final straight in Lane 1"));
      break;

    case ROUTE_STOPPED:
      Serial.println(F("Track complete. Stopping."));
      motorStop();
      Center_Steering();
      robotStopped = true;
      break;

    default:
      break;
  }
}

void Update_Route() {
  float distanceCm = readDistance();

  if (distanceCm >= TRACK_TOTAL_LENGTH) {
    Change_Route_State(ROUTE_STOPPED);
    return;
  }

  RouteState nextState = ROUTE_NONE;
  float nextTargetYaw = baseYaw;

  // -------------------------------------------------
  // 1) Start from middle and move to Lane 1
  // -------------------------------------------------
  if (distanceCm < INITIAL_LANE_CHANGE_END) {
    nextState = ROUTE_INITIAL_TO_LANE1;

    if (distanceCm < INITIAL_LANE_CHANGE_MID) {
      float progress = getProgress(distanceCm,
                                   INITIAL_LANE_CHANGE_START,
                                   INITIAL_LANE_CHANGE_MID);

      nextTargetYaw = baseYaw + (LANE_SIDE_SIGN * INITIAL_LANE_YAW_ANGLE * progress);
    }
    else {
      float progress = getProgress(distanceCm,
                                   INITIAL_LANE_CHANGE_MID,
                                   INITIAL_LANE_CHANGE_END);

      nextTargetYaw = baseYaw + (LANE_SIDE_SIGN * INITIAL_LANE_YAW_ANGLE * (1.0 - progress));
    }
  }

  // -------------------------------------------------
  // 2) Continue straight in Lane 1
  // -------------------------------------------------
  else if (distanceCm < LC1_START) {
    nextState = ROUTE_LANE1_STRAIGHT;
    nextTargetYaw = baseYaw;
  }

  // -------------------------------------------------
  // 3) Before obstacle 1, switch from Lane 1 to Lane 2
  // -------------------------------------------------
  else if (distanceCm < LC1_END) {
    nextState = ROUTE_LANE1_TO_LANE2;

    float laneYaw = laneChangeYawProfile(distanceCm,
                                         LC1_START,
                                         LC1_RAMP_END,
                                         LC1_HOLD_END,
                                         LC1_END,
                                         FULL_LANE_YAW_ANGLE);

    nextTargetYaw = baseYaw - (LANE_SIDE_SIGN * laneYaw);
  }

  // -------------------------------------------------
  // 4) Continue straight in Lane 2
  // -------------------------------------------------
  else if (distanceCm < LC2_START) {
    nextState = ROUTE_LANE2_STRAIGHT;
    nextTargetYaw = baseYaw;
  }

  // -------------------------------------------------
  // 5) Before obstacle 2, switch from Lane 2 to Lane 1
  // -------------------------------------------------
  else if (distanceCm < LC2_END) {
    nextState = ROUTE_LANE2_TO_LANE1;

    float laneYaw = laneChangeYawProfile(distanceCm,
                                         LC2_START,
                                         LC2_RAMP_END,
                                         LC2_HOLD_END,
                                         LC2_END,
                                         FULL_LANE_YAW_ANGLE);

    nextTargetYaw = baseYaw + (LANE_SIDE_SIGN * laneYaw);
  }

  // -------------------------------------------------
  // 6) Final straight to finish line
  // -------------------------------------------------
  else {
    nextState = ROUTE_FINAL_STRAIGHT;
    nextTargetYaw = baseYaw;
  }

  if (routeState != nextState) {
    Change_Route_State(nextState);
  }

  targetYaw = nextTargetYaw;
}

// ================= PID YAW CONTROL =================
void Maintain_Yaw() {
  if (!Update_Yaw()) return;

  float currentYaw = Get_Yaw();

  unsigned long now = millis();
  float dt = (now - lastPIDTime) / 1000.0;

  if (dt <= 0.0) return;

  lastPIDTime = now;

  yawError = Angle_Error(targetYaw, currentYaw);

  yawIntegral += yawError * dt;
  yawIntegral = constrain(yawIntegral, -MAX_INTEGRAL, MAX_INTEGRAL);

  yawDerivative = (yawError - lastYawError) / dt;
  lastYawError = yawError;

  float pidOutput = (Kp * yawError) + (Ki * yawIntegral) + (Kd * yawDerivative);
  pidOutput = constrain(pidOutput, -MAX_PID_OUTPUT, MAX_PID_OUTPUT);

  int servoAngle = round(STEERING_CENTER_ANGLE + (STEERING_DIRECTION * pidOutput));
  servoAngle = constrain(servoAngle, STEERING_MIN_ANGLE, STEERING_MAX_ANGLE);

  Set_Steering(servoAngle);

  if (now - lastSerialPrintTime >= SERIAL_PRINT_INTERVAL_MS) {
    lastSerialPrintTime = now;

    Serial.print(F("Yaw: "));
    Serial.print(currentYaw, 2);

    Serial.print(F(" | Target: "));
    Serial.print(targetYaw, 2);

    Serial.print(F(" | Err: "));
    Serial.print(yawError, 2);

    Serial.print(F(" | Dist(cm): "));
    Serial.print(readDistance(), 1);

    Serial.print(F(" | PWM: "));
    Serial.println(motorPWM);
  }
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(MOTOR_ENA_PIN, OUTPUT);
  pinMode(MOTOR_IN1_PIN, OUTPUT);
  pinMode(MOTOR_IN2_PIN, OUTPUT);

  motorStop();

  pinMode(ENCODER_A_PIN, INPUT_PULLUP);
  pinMode(ENCODER_B_PIN, INPUT_PULLUP);

  lastEncoderState = (digitalRead(ENCODER_A_PIN) << 1) | digitalRead(ENCODER_B_PIN);

  attachInterrupt(digitalPinToInterrupt(ENCODER_A_PIN), updateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_B_PIN), updateEncoder, CHANGE);

  resetDistance();

  steeringServo.attach(STEERING_SERVO_PIN);
  Center_Steering();

  Wire.begin();
  Wire.setClock(100000);

  mpu.initialize();

  if (!mpu.testConnection()) {
    Serial.println(F("MPU FAILED"));
    while (1);
  }

  uint8_t devStatus = mpu.dmpInitialize();

  mpu.setXGyroOffset(220);
  mpu.setYGyroOffset(76);
  mpu.setZGyroOffset(-85);
  mpu.setZAccelOffset(1788);

  if (devStatus == 0) {
    delay(500);

    mpu.CalibrateAccel(6);
    mpu.CalibrateGyro(6);

    mpu.setDMPEnabled(true);
    dmpReady = true;
  }
  else {
    Serial.println(F("DMP FAILED"));
    while (1);
  }

  delay(1000);

  Reset_Target_Yaw_To_Current();
  baseYaw = targetYaw;

  Serial.println(F("System ready. Starting straight obstacle track..."));

  motorForward(motorPWM);
}

// ================= LOOP =================
void loop() {
  Update_Route();

  if (!robotStopped) {
    Maintain_Yaw();
  }

  delay(50);
}