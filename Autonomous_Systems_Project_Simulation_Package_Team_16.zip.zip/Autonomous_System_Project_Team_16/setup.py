from setuptools import find_packages, setup
import glob
import os

_here = os.path.abspath(os.path.dirname(__file__))

package_name = 'Autonomous_System_Project_Team_22'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/Autonomous_System_Project_Team_22/launch',
            ['launch/Autonomous_Systems_MS_2_Team_22.launch.py']),
        ('share/Autonomous_System_Project_Team_22/launch',
            ['launch/Autonomous_Systems_MS_3_Team_22.launch.py']),
        ('share/Autonomous_System_Project_Team_22/launch',
            ['launch/Autonomous_Systems_MS_4_Team_22.launch.py']),
        # ('share/Autonomous_System_Project_Team_22/launch',
        #     ['launch/Autonomous_Systems_MS_4_PathPlanner_Team_22.launch.py']),
        # ('share/Autonomous_System_Project_Team_22/Worlds', 
        #     glob.glob('Worlds/*.world')),
        ('share/Autonomous_System_Project_Team_22/rviz',
            ['rviz/planning.rviz'])
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='michool',
    maintainer_email='michool@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        'olr_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_2_OLR_Team_22:main',
        'teleop_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_2_Teleop_Team_22:main',
        'teleop_pub = Autonomous_System_Project_Team_22.publisher:main',
        'speed_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_3_CLR_Alg_1_Speed_Team_22:main',
        'lateral_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_3_CLR_Alg_2_Lateral_Team_22:main',
        'constraint_node = Autonomous_System_Project_Team_22.vehicle_constraint_node:main',
        'pi_constraint_node = Autonomous_System_Project_Team_22.pi_vehicle_constraint_node:main',
        'planning_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_4_Planning_Team_22:main',
        'path_planner_node = Autonomous_System_Project_Team_22.path_planner_node:main',
        ],
    },
)
