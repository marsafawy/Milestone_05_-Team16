from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    # -------- Launch Arguments --------
    desired_speed = LaunchConfiguration('desired_speed')
    desired_lane  = LaunchConfiguration('desired_lane')

    speed_arg = DeclareLaunchArgument(
        'desired_speed',
        default_value='0.5'
    )

    lane_arg = DeclareLaunchArgument(
        'desired_lane',
        default_value='2.0'
    )


    # -------- Gazebo --------
    gazebo = ExecuteProcess(
        cmd=[
            'gz',
            'sim',
            '-r',
            'ackermann_steering.sdf'
        ],
        output='screen'
    )


    # -------- Bridge --------
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
          '/model/vehicle_blue/cmd_vel'
          '@geometry_msgs/msg/Twist'
          '@gz.msgs.Twist',

          '/model/vehicle_blue/odometry'
          '@nav_msgs/msg/Odometry'
          '@gz.msgs.Odometry',
        ],
        output='screen'
    )


    # -------- Speed Controller --------
    speed_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='speed_node',
        parameters=[
            {
                'desired_speed': desired_speed
            }
        ],
        output='screen'
    )


    # -------- Stanley Controller --------
    lateral_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='lateral_node',
        parameters=[
            {
                'desired_y': desired_lane
            }
        ],
        output='screen'
    )

    constraint_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='constraint_node',
        name='constraint_node',
        output='screen'
    )

    # -------- rqt graph --------
    graph = ExecuteProcess(
        cmd=['rqt_graph'],
        output='screen'
    )


    return LaunchDescription([
        speed_arg,
        lane_arg,
        gazebo,
        bridge,
        speed_node,
        lateral_node,
        constraint_node,
        graph
    ])