import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def _rviz_config_path():
    # Try installed path first, fall back to source path
    try:
        pkg = get_package_share_directory('Autonomous_System_Project_Team_22')
        cfg = os.path.join(pkg, 'rviz', 'planning.rviz')
        if os.path.isfile(cfg):
            return cfg
    except Exception:
        pass
    # Fallback: use the source file directly
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'rviz', 'planning.rviz')

def launch_setup(context, *args, **kwargs):
    map_choice = LaunchConfiguration('map').perform(context)
    
    if map_choice == 'empty':
        world_name = 'Empty_track.world'
    elif map_choice == 'racing':
        world_name = 'Racing_Track.world'
    elif map_choice == 'city':
        world_name = 'City_Track.world'
    else:
        world_name = 'Empty_track.world' # Default fallback

    pkg_share = get_package_share_directory('Autonomous_System_Project_Team_22')
    world_file = os.path.join(pkg_share, 'Worlds', world_name)

    # -------- Gazebo --------
    gazebo = ExecuteProcess(
        cmd=[
            'gz',
            'sim',
            '-r',
            world_file
        ],
        output='screen'
    )
    return [gazebo]


def generate_launch_description():

    # -------- Launch Arguments --------
    map_arg = DeclareLaunchArgument(
        'map',
        default_value='empty',
        description='Choose map: empty, racing, or city'
    )

    # -------- Bridge --------
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
          '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
          '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
        ],
        output='screen'
    )

    # -------- Planning Node --------
    planning_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='planning_node',
        name='planning_node',
        parameters=[
            {'map': LaunchConfiguration('map')}
        ],
        output='screen'
    )

    # -------- Speed Controller --------
    speed_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='speed_node',
        name='speed_node',
        output='screen'
    )

    # -------- Stanley Controller --------
    lateral_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='lateral_node',
        name='lateral_node',
        output='screen'
    )

    # -------- Constraint Node --------
    constraint_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='constraint_node',
        name='constraint_node',
        output='screen'
    )

    # -------- rqt graph --------
    graph = ExecuteProcess(
        cmd=['rqt_graph'],
        output='screen'
    )

    # -------- RViz --------
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', _rviz_config_path()],
        output='screen'
    )

    return LaunchDescription([
        map_arg,
        OpaqueFunction(function=launch_setup),
        bridge,
        planning_node,
        speed_node,
        lateral_node,
        constraint_node,
        graph,
        rviz_node
    ])
