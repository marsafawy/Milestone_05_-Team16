import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def launch_setup(context, *args, **kwargs):
    map_choice = LaunchConfiguration('map').perform(context)

    # Select Gazebo world
    if map_choice == 'empty':
        world_name = 'Empty_track.world'
    elif map_choice == 'racing':
        world_name = 'Racing_Track.world'
    elif map_choice == 'city':
        world_name = 'City_Track.world'
    else:
        world_name = 'Empty_track.world'  # Default fallback

    pkg_share = get_package_share_directory('Autonomous_System_Project_Team_22')
    world_file = os.path.join(pkg_share, 'Worlds', world_name)

    # Map 'map' argument → path_planner track name
    #   empty  → track_1
    #   racing → track_2
    #   city   → track_3
    track_map = {'empty': 'track_1', 'racing': 'track_2', 'city': 'track_3'}
    track_name = track_map.get(map_choice, 'track_1')

    # -------- Gazebo --------
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )

    # -------- Path Planner Node --------
    path_planner_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='path_planner_node',
        name='path_planner_node',
        parameters=[
            {'track_name': track_name},
            {'cruise_speed': 0.30},
            {'curve_speed': 0.20},
            {'lookahead_distance': 0.20},
            {'waypoint_tolerance': 0.15},
            {'trajectory_resolution': 0.02},
            {'goal_tolerance': 0.25},
            {'max_lateral_accel': 0.3},
            {'control_rate': 20.0},
            {'start_delay': 2.0},
        ],
        output='screen'
    )

    return [gazebo, path_planner_node]


def generate_launch_description():

    # -------- Launch Arguments --------
    map_arg = DeclareLaunchArgument(
        'map',
        default_value='empty',
        description='Choose map: empty, racing, or city'
    )

    # -------- Bridge --------
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
        ],
        output='screen'
    )

    # -------- Speed Controller --------
    speed_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='speed_node',
        name='speed_node',
        output='screen'
    )

    # -------- Stanley Lateral Controller --------
    lateral_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='lateral_node',
        name='lateral_node',
        output='screen'
    )

    # -------- Constraint Node --------
    constraint_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='constraint_node',
        name='constraint_node',
        output='screen'
    )

    # -------- rqt graph --------
    graph = ExecuteProcess(
        cmd=['rqt_graph'],
        output='screen'
    )

    return LaunchDescription([
        map_arg,
        OpaqueFunction(function=launch_setup),
        bridge,
        speed_node,
        lateral_node,
        constraint_node,
        graph
    ])
