import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import math


class LateralController(Node):
    """
    Enhanced Stanley Lateral Controller
    ====================================
    steering = k_heading * heading_error
             + atan2(k_stanley * e_cte, v + k_soft)
             + k_d_heading * d(heading_error)/dt

    Where:
        e_cte              = perpendicular distance from car to desired path line
        heading_error      = desired_heading - current_yaw  (normalized to [-π, π])
        d(heading_error)/dt= rate of change of heading error (damping term)
                             accessed directly from yaw_rate via odometry
        k_heading          = heading proportional gain (> 1 for aggressive heading alignment)
        k_stanley          = cross-track gain
        k_soft             = softening constant (avoids div-by-zero at low speed)
        k_d_heading        = heading derivative damping gain
        v                  = current longitudinal speed [m/s]
    """

    def __init__(self):
        super().__init__('lateral_controller_stanley')

        self.declare_parameter('desired_y', 0.1875)
        self.desired_y = self.get_parameter('desired_y').value

        # ── Gains (Extended Stanley) ──
        self.k_heading   = 1.2    # heading proportional (anticipates curves)
        self.k_stanley   = 0.5    # cross-track gain (lowered to reduce oscillation)
        self.k_soft      = 0.1    # softening constant (prevents atan2 blow-up at v≈0)
        self.k_d_heading = 0.4    # heading derivative damping (increased to suppress oscillation)
        self.lookahead   = 0.15   # lookahead distance to steer earlier

        # ── State ──
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.current_speed = 0.0
        self.yaw_rate = 0.0       # directly from odometry twist.angular.z
        self.path_heading = 0.0
        self.desired_x = 0.0      # target X from planner
        self.desired_y_pos = 0.0  # target Y from planner (actual coordinate)

        # ── Subscribers ──
        self.create_subscription(
            Odometry, '/model/vehicle_blue/odometry', self.odom_callback, 10)
        self.create_subscription(
            Float64, '/planning/desired_lane', self.desired_lane_callback, 10)
        self.create_subscription(
            Float64, '/planning/desired_heading', self.desired_heading_callback, 10)
        self.create_subscription(
            Float64, '/planning/desired_x', self.desired_x_callback, 10)
        self.create_subscription(
            Float64, '/planning/desired_y', self.desired_y_callback, 10)

        # ── Publishers ──
        self.pub = self.create_publisher(Float64, '/desired_steering_cmd', 10)
        self.lane_pub = self.create_publisher(Float64, '/desired_lane_cmd', 10)

        # ── Control loop (50 Hz) ──
        self.create_timer(0.02, self.control_loop)

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------
    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.current_speed = msg.twist.twist.linear.x

        # Yaw rate directly from odometry — no numerical differentiation
        self.yaw_rate = msg.twist.twist.angular.z

        # Quaternion → Yaw
        q = msg.pose.pose.orientation
        siny = 2 * (q.w * q.z + q.x * q.y)
        cosy = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.yaw = math.atan2(siny, cosy)

    def desired_lane_callback(self, msg):
        self.desired_y = msg.data

    def desired_heading_callback(self, msg):
        self.path_heading = msg.data

    def desired_x_callback(self, msg):
        self.desired_x = msg.data

    def desired_y_callback(self, msg):
        self.desired_y_pos = msg.data

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    # ------------------------------------------------------------------
    # Control loop
    # ------------------------------------------------------------------
    def control_loop(self):

        # Add lookahead to current position to "steer earlier"
        lookahead_x = self.x + self.lookahead * math.cos(self.yaw)
        lookahead_y = self.y + self.lookahead * math.sin(self.yaw)

        # ── 1. Cross-track error (perpendicular distance to path) ──
        # dx, dy = displacement from desired point to projected position
        dx = lookahead_x - self.desired_x
        dy = lookahead_y - self.desired_y_pos

        # Perpendicular distance from car to the path line through
        # (desired_x, desired_y) with direction path_heading.
        # Positive e_cte → car is to the right of path → steer left
        e_cte = math.sin(self.path_heading) * dx - math.cos(self.path_heading) * dy

        # ── 2. Heading error ──
        heading_error = self.normalize_angle(self.path_heading - self.yaw)

        # ── 3. Heading error derivative (damping) ──
        # d(heading_error)/dt = d(path_heading)/dt - d(yaw)/dt
        # path_heading is quasi-static between planner updates → ≈ 0
        # d(yaw)/dt = yaw_rate from odometry
        # So d(heading_error)/dt ≈ -yaw_rate
        d_heading_error = -self.yaw_rate

        # ── 4. Speed (with softening) ──
        v = max(abs(self.current_speed), 0.01)

        # ── 5. Enhanced Stanley control law ──
        steer_heading = self.k_heading * heading_error
        steer_cte     = math.atan2(self.k_stanley * e_cte, v + self.k_soft)
        steer_damping = self.k_d_heading * d_heading_error

        steering = steer_heading + steer_cte + steer_damping

        # ── 6. Saturation ──
        steering = max(min(steering, 0.5), -0.5)

        # ── 7. Publish ──
        msg = Float64()
        msg.data = steering
        self.pub.publish(msg)

        lane_msg = Float64()
        lane_msg.data = self.desired_y
        self.lane_pub.publish(lane_msg)

        # ── Debug (throttled 1 Hz) ──
        self.get_logger().info(
            f"X={self.x:.2f} Y={self.y:.2f} dX={self.desired_x:.2f} dY={self.desired_y_pos:.2f} "
            f"dx={dx:.3f} dy={dy:.3f} CTE={e_cte:.3f} "
            f"HdgErr={heading_error:.2f} dHdg={d_heading_error:.2f} "
            f"Steer={steering:.2f}",
            throttle_duration_sec=1.0
        )


def main():
    rclpy.init()
    node = LateralController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()