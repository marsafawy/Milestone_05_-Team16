from nav_msgs import msg
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64


class SpeedController(Node):

    def __init__(self):
        super().__init__('speed_controller')

        # Parameters
        self.declare_parameter('desired_speed', 0.25)  # Desired speed in m/s
        self.declare_parameter('kp', 0.7)  # Proportional gain
        self.declare_parameter('ki', 1.0)  # Integral gain
        self.declare_parameter('max_velocity', 1.0)  # Max cmd velocity (vehicle max)

        self.desired_speed = self.get_parameter('desired_speed').value
        self.kp = self.get_parameter('kp').value
        self.ki = self.get_parameter('ki').value
        self.max_velocity = self.get_parameter('max_velocity').value
        
        self.current_speed = 0.0
        self.integral_error = 0.0
        self.dt = 0.1
                
        # Subscriber
        self.create_subscription(
            Odometry,
            '/model/vehicle_blue/odometry',
            self.odom_callback,
            10
        )

        self.create_subscription(
            Float64,
            '/planning/desired_speed',
            self.desired_speed_callback,
            10
        )

        # Publisher
        self.pub=self.create_publisher(
            Float64,
            '/desired_speed_cmd',
            10
        )

        # Timer
        self.create_timer(self.dt, self.control_loop)

    def odom_callback(self, msg):
        self.current_speed = msg.twist.twist.linear.x

    def desired_speed_callback(self, msg):
        self.desired_speed = msg.data

    def control_loop(self):
        if self.desired_speed == 0.0:
            self.integral_error = 0.0
            msg = Float64()
            msg.data = 0.0
            self.pub.publish(msg)
            return

        error = self.desired_speed - self.current_speed
        
        # Integral term with anti-windup
        self.integral_error += error * self.dt
        self.integral_error = max(-0.9, min(0.9, self.integral_error))
        
        # PI control
        control = (self.kp * error + 
                   self.ki * self.integral_error)
        
        # Velocity saturation
        control = max(-self.max_velocity, min(self.max_velocity, control))

        msg=Float64()
        msg.data=control
        self.pub.publish(msg)
        
        self.get_logger().info(
            f"Speed: {self.current_speed:.2f}, Desired: {self.desired_speed:.2f}, "
            f"Error: {error:.2f}, Cmd: {control:.2f}"
        )


def main():
    rclpy.init()
    node = SpeedController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()