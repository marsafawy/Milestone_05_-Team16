import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import sys
import termios
import tty

speed = 0.0
steering = 0.0


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch1 = sys.stdin.read(1)

        if ch1 == '\x1b':
            ch2 = sys.stdin.read(1)
            ch3 = sys.stdin.read(1)
            return ch1 + ch2 + ch3
        else:
            return ch1
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def odom_callback(msg):
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    vx = msg.twist.twist.linear.x
    wz = msg.twist.twist.angular.z

    print(f"[STATE] Pos: ({x:.2f}, {y:.2f}) | Vel: {vx:.2f} | Steering: {wz:.2f}")


def main():
    global speed, steering

    rclpy.init()
    node = rclpy.create_node('teleop_node')

    # Publisher
    pub = node.create_publisher(
        Twist,
        '/model/vehicle_blue/cmd_vel',
        10
    )

    # Subscriber
    node.create_subscription(
        Odometry,
        '/model/vehicle_blue/odometry',
        odom_callback,
        10
    )

    print("Teleop started:")
    print("↑ forward | ↓ backward | ← left | → right | s stop | q quit")

    while True:
        key = get_key()

        if key == '\x1b[A':      # UP
            speed += 0.5
        elif key == '\x1b[B':    # DOWN
            speed -= 0.5
        elif key == '\x1b[C':    # RIGHT
            steering -= 0.1
        elif key == '\x1b[D':    # LEFT
            steering += 0.1
        elif key == 's':
            speed = 0.0
            steering = 0.0
        elif key == 'q':
            break

        msg = Twist()
        msg.linear.x = speed
        msg.angular.z = steering
        pub.publish(msg)

        print(f"[CMD] Speed: {speed:.2f}, Steering: {steering:.2f}")

        rclpy.spin_once(node, timeout_sec=0.01)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
